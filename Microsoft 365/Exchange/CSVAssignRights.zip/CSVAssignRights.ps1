﻿$USERS = Import-Csv c:\temp\accessusers.csv

foreach ($user in $USERS) {

    $user = Add-MailboxPermission -Identity $user.mailbox -User $user.delegate -AccessRights FullAccess -InheritanceType All
}
