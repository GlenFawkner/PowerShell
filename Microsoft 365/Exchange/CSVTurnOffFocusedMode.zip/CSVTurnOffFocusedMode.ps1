﻿$USERS = Import-Csv C:\Temp\NetlogixUsers.csv

foreach($user in $USERS) {

 $user = Set-FocusedInbox -Identity $user.Email -FocusedInboxOn $false
}